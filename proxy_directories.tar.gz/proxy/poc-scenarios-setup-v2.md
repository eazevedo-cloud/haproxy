# PoC Scenarios Setup

## Overview

This document outlines the setup process for various Proof of Concept (PoC) scenarios involving Virtual Machines (VMs) and an AKS cluster.

---

## Scenario 1

### Setup

- **Virtual Machine [haproxy-scenario-1]**  
  - IP: `172.20.132.133`
  
- **Virtual Machine [vm-on-premise]**  
  - IP: `10.37.0.4`
  
- **Kubernetes Cluster**  
  - Name: [poc-mercury]

### Steps

1. **Start the following resources:**
   - VM [haproxy-scenario-1]
   - VM [vm-on-premise]
   - AKS Cluster [poc-mercury]

1. **Configure Load Balancer:**
   - Set the health check timeout to **300 seconds**.

1. **Connect to the HAProxy VM:**

   ```bash
   ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@172.20.132.133
   ```

1. **Update Ingress Configuration:**

    ```sh
    kubectl apply -f k8s-setup/istio-simple-routing.yaml
    ```

1. **Connect to the On-Premise VM:**

    ```sh
    ssh -i poc-mercury-vm_key.pem azureuser@10.37.0.4
    ```

1. **Run Socket Server:**

    ```sh
    python3 server-scenario-1.py
    ```

1. **Open a New Terminal and Reconnect to HAProxy VM:**

    ```sh
    ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@172.20.132.133
    ```

1. **Launch K9s to Monitor Logs:**

    ```sh
    k9s
    ```

    - Open the pod server log to monitor during the demo.

1. **Update Client Configuration:**
    - Modify client.py to send messages to:
      - IP: 172.20.132.133
      - Port: 5021

1. **Run the Client Script:**

    ```sh
    python3 client.py
    ```

## Scenario 2

### Setup

- **Virtual Machine [haproxy-scenario-1]**
  - IP: 172.20.132.133
- **Virtual Machine [vm-on-premise]**
  - IP: 10.37.0.4
- **Kubernetes Cluster**
  - Name: [poc-mercury]

### Steps

1. **Start the following resources:**
    - VM [haproxy-scenario-1]
    - VM [vm-on-premise]
    - AKS Cluster [poc-mercury]

1. **Configure Load Balancer:**
    - Set the health check timeout to 300 seconds.

1. **Connect to the HAProxy VM:**

    ```sh
    ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@172.20.132.133
    ```

1. **Update Ingress Configuration (optional if Scenario 1 was already executed):**

    ```sh
    kubectl apply -f k8s-setup/istio-simple-routing.yaml
    ```

1. **Connect to the On-Premise VM:**

    ```sh
      ssh -i poc-mercury-vm_key.pem azureuser@10.37.0.4
    ```

1. **Run Socket Server:**

    ```sh
    python3 server-scenario-1.py
    ```

1. **Open a New Terminal and Reconnect to HAProxy VM:**

    ```sh
    ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@172.20.132.133
    ```

1. **Launch K9s to Monitor Logs:**

    ```sh
    k9s
    ```

    - Open the pod server log to monitor during the demo.

1. **Update Client Configuration:**
    - Modify client-loop.py to send messages to:
      - IP: 172.20.132.133
      - Port: 5021

1. **Run the Client Loop Script:**

    ```sh
    python3 client-loop.py
    ```

## Scenario 3

### Setup

- **Virtual Machine [haproxy-scenario-3]**
  - IP: 172.20.132.134
- **Virtual Machine [vm-on-premise]**
  - IP: 10.37.0.4
- **Virtual Machine [vm-client]**
  - IP: 157.56.179.91
- **Kubernetes Cluster**
  - Name: [poc-mercury]

### Steps

1. **Start the following resources:**
    - VM [haproxy-scenario-3]
    - VM [vm-on-premise]
    - AKS Cluster [poc-mercury]

1. **Connect to the HAProxy VM:**

    ```sh
    ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@172.20.132.134
    ```

1. **Update Ingress Configuration:**

    ```sh
    kubectl apply -f k8s-setup/istio-simple-routing-scenario3.yaml
    ```

1. **Connect to the On-Premise VM:**

    ```sh
    ssh -i poc-mercury-vm_key.pem azureuser@10.37.0.4
    ```

1. **Run Socket Server:**

    ```sh
    python3 server-scenario-3.py
    ```

1. **Update Client Configuration:**
    - Modify client.py to send messages to:
      - IP: 172.20.132.134
      - Port: 5021

1. **Run the Client Script from Local Machine:**

    ```sh
    python3 client.py
    ```

1. **Connect to the Client VM:**

    ```sh
    ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@157.56.179.91
    ```

1. **Run the Client Script on Client VM:**

    ```sh
    python3 client.py
    ```

1. **Open a New Terminal and Reconnect to HAProxy VM:**

    ```sh
    ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@172.20.132.134
    ```

1. **Launch K9s to Monitor Logs:**

    ```sh
    k9s
    ```

    - Open the pod server log to monitor during the demo.

1. **Edit HAProxy Configuration:**

    ```sh
    sudo vi /etc/haproxy/haproxy.cfg
    ```

    - Change the following lines to redirect IP forwarding messages as needed:

    ```sh
    # Redirect based on ACLs  
    # use_backend backend_cluster if local_machine  
    # use_backend backend_vm_on_premise if vm_client  
    use_backend backend_cluster if vm_client  
    use_backend backend_vm_on_premise if local_machine
    ```

1. **Restart HAProxy Service:**

    ```sh
    sudo service haproxy restart
    ```

1. **Run the Client Script to Demonstrate Message Routing Change:**

    ```sh
    python3 client.py
    ```
