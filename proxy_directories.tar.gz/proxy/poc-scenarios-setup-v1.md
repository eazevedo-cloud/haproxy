# PoC Scenarios Setup

## Scenario 1

Given the following setup:

- Virtual Machine [haproxy-scenario-1] IP: `172.20.132.133`.
- Virutal Machine [vm-on-premise] IP: `10.37.0.4`.
- Kubernetes Cluster: [poc-mercury].

Follow the steps below:

1. Turn on the VM's [haproxy-scenario-1] IP: `172.20.132.133`, [vm-on-premise] and [poc-mercury] AKS Cluster  
1. Change the health check timeout of the load balancer to 300 seconds.  
1. Connect in the [haproxy-scenario-1] VM using the command `ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@172.20.132.133`  
1. Run the command `kubectl apply -f k8s-setup/istio-simple-routing.yaml` to change the ingress configuration to the scenario-1 in the AKS cluster  
1. Runt the command `ssh -i poc-mercury-vm_key.pem azureuser@10.37.0.4` to connect in the [vm-on-premise] VM.  
1. Run the command `python3 server-scenario-1.py` to execute the socket server in the VM on premise  
1. Open a new terminal, and connect again in the [haproxy-scenario-1] VM using the command `ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@172.20.132.133`  
1. Run the command `k9s`, and then open the pod server log to be followed during the demo.  
1. On the local VM, adjust the `client.py` file to send messages to the IP `172.20.132.133`, port `5021`.  
1. On the local VM, Run the client.py script with the command `python3 client.py`  

## Scenario 2

Given the following setup:

- Virtual Machine [haproxy-scenario-1] IP: `172.20.132.133`.
- Virutal Machine [vm-on-premise] IP: `10.37.0.4`.
- Kubernetes Cluster: [poc-mercury].

Follow the steps below:

1. Turn on the VM's [haproxy-scenario-1], [vm-on-premise] and [poc-mercury] AKS Cluster  
1. Change the health check timeout of the load balancer to 300 seconds.  
1. Connect in the [haproxy-scenario-1] VM using the command `ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@172.20.132.133`  
1. (*Optional if the previous Scenario was 1*) Run the command `kubectl apply -f k8s-setup/istio-simple-routing.yaml` to change the ingress configuration to the scenario-1 in the AKS cluster  
1. Runt the command `ssh -i poc-mercury-vm_key.pem azureuser@10.37.0.4` to connect in the [vm-on-premise] VM.  
1. Run the command `python3 server-scenario-1.py` to execute the socket server in the VM on premise  
1. Open a new terminal, and connect again in the [haproxy-scenario-1] VM using the command `ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@172.20.132.133`  
1. Run the command `k9s`, and then open the pod server log to be followed during the demo.  
1. On the local VM, adjust the `client-loop.py` file to send messages to the IP `172.20.132.133`, port `5021`.  
1. On the local VM, Run the client.py script with the command `python3 client-loop.py`

## Scenario 3

Given the following setup:

- Virtual Machine [haproxy-scenario-1] IP: `172.20.132.134`.
- Virutal Machine [vm-on-premise] IP: `10.37.0.4`.
- Virtual Machine [vm-client] IP: `157.56.179.91`.
- Kubernetes Cluster: [poc-mercury].

Follow the steps below:

1. Turn on the VM's [haproxy-scenario-3], [vm-on-premise] and [poc-mercury] AKS Cluster  
1. Connect in the [haproxy-scenario-3] VM using the command `ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@172.20.132.134`  
1. Run the command `kubectl apply -f k8s-setup/istio-simple-routing-scenario3.yaml` to change the ingress configuration to the scenario-3 in the AKS cluster  
1. Runt the command `ssh -i poc-mercury-vm_key.pem azureuser@10.37.0.4` to connect in the [vm-on-premise] VM.  
1. Run the command `python3 server-scenario-3.py` to execute the socket server in the VM on premise  
1. Adjust the `client.py` file to send messages to the IP `172.20.132.134`, port `5021`.  
1. Run the `client.py` script with the command `python3 client.py` to send messages via local machine.  
1. Connect to the client vm using the command `ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@157.56.179.91`  
1. Run the command `python3 client.py` to send message via client vm.  
1. Open a new terminal, and connect again in the [haproxy-scenario-3] VM using the command `ssh -i ./bastion/poc-mercury-vm_key.pem azureuser@172.20.132.134`  
1. Run the command `k9s`, and then open the pod server log to be followed during the demo.  
1. In the [haproxy-scenario-3], run the command `sudo vi /etc/haproxy/haproxy.cfg` to edit the haproxy.cfg configuration file and change the commented code as below to switch the ip forwarding message from local\_machine to vm\_client (or vice-versa):

        \# Redirect based on ACLs  
        \# use\_backend backend\_cluster if local\_machine  
        \# use\_backend backend\_vm\_on\_premise if vm\_client  
        use\_backend backend\_cluster if vm\_client  
        use\_backend backend\_vm\_on\_premise if local\_machine

1. Restart the HAProxy server running the command `sudo service haproxy restart`  
1. Run the `client.py` script to show the message routing change in the vm\_client and in the local\_machine.
