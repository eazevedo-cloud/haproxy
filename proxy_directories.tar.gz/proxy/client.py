import socket


def client():
    # Create a socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Define the address and port of the server
    address = ("172.20.132.134", 5021)

    # Connect to the server
    client_socket.connect(address)

    # Send a message
    message = "Hello, SITA, this is Scenario 3!"
    client_socket.sendall(message.encode())

    # Receive the response from the server
    data = client_socket.recv(1024)
    print(f"Received from server: {data.decode()}")

    # Close the socket
    client_socket.close()


if __name__ == "__main__":
    client()
