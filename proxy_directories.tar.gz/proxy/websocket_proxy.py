import socket
import asyncio
import websockets
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)

# WebSocket server to forward messages
WEBSOCKET_SERVER_URL = "ws://10.37.0.4:8765"

# Socket server configuration
SOCKET_HOST = "0.0.0.0"
SOCKET_PORT = 5030


# Function to forward messages to the WebSocket server
async def forward_to_websocket(message):
    try:
        async with websockets.connect(
            WEBSOCKET_SERVER_URL, additional_headers={"Load-Balancer": "ServerA"}
        ) as websocket:
            await websocket.send(message)
            # response = await websocket.recv()
            # logging.info(f"Response from WebSocket server: {response}")
            logging.info(f"Message sent: {message}")
    except Exception as e:
        logging.error(f"Error forwarding message to WebSocket server: {e}")


# Function to handle socket client connections
def handle_socket_client(client_socket):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    try:
        while True:
            # Receive data from the socket client
            data = client_socket.recv(1024).decode("utf-8")
            if not data:
                break
            logging.info(f"Received message from socket client: {data}")

            # Forward the message to the WebSocket server
            loop.run_until_complete(forward_to_websocket(data))
    except Exception as e:
        logging.error(f"Error handling socket client: {e}")
    finally:
        logging.info("Closing client socket connection.")
        client_socket.close()


# Function to start the socket server
def start_socket_server():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((SOCKET_HOST, SOCKET_PORT))
        server_socket.listen(5)
        logging.info(f"Socket server listening on {SOCKET_HOST}:{SOCKET_PORT}")

        while True:
            client_socket, client_address = server_socket.accept()
            logging.info(f"Connection accepted from {client_address}")
            handle_socket_client(client_socket)


# Entry point for the script
if __name__ == "__main__":
    try:
        start_socket_server()
    except KeyboardInterrupt:
        logging.info("Socket server shutting down.")
