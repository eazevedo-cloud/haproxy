#!/usr/bin/env python

"""Echo server using the asyncio API."""

import asyncio
import logging
from websockets.asyncio.server import serve

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)


async def echo(websocket):
    async for message in websocket:
        logging.info(f"Message: {message}")
        logging.info(f"Header: {websocket.request.headers}")


async def main():
    async with serve(echo, "0.0.0.0", 8765) as server:
        await server.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())
