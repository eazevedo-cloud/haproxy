import socket
import logging
import select
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)


def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("0.0.0.0", 5030))  # Listening on all interfaces on port 5030
    server_socket.listen(5)

    # Set the server socket to non-blocking mode
    server_socket.setblocking(False)

    logging.info("Server listening on port 5030...")

    # Dictionary to keep track of client sockets and their addresses
    client_sockets = {}

    while True:
        # Using select to wait for socket activity
        try:
            # Wait for sockets to be ready for reading
            ready_to_read, _, _ = select.select(
                [server_socket] + list(client_sockets.keys()), [], [], 1
            )  # 1 second timeout
            for s in ready_to_read:
                if s == server_socket:
                    # Accept a new client connection
                    client_socket, addr = server_socket.accept()
                    logging.info(f"Connection received from {addr}")
                    client_socket.setblocking(
                        False
                    )  # Set the client socket to non-blocking mode
                    client_sockets[client_socket] = (
                        addr  # Store the client socket and its address
                    )

                else:
                    # Handle communication with existing clients
                    try:
                        data = s.recv(1024)
                        if not data:
                            # Log the address of the client that closed the connection
                            logging.info(
                                f"Connection closed by the client: {client_sockets[s]}"
                            )
                            del client_sockets[
                                s
                            ]  # Remove the socket from the dictionary
                            s.close()  # Close the socket
                            continue

                        # Log the received data
                        logging.info(f"Received: {data.decode()}")

                        # Send a response back to the client
                        response_message = f"Message received -> VM: {data.decode()}"
                        s.sendall(response_message.encode())

                    except BlockingIOError:
                        # No data available, continue the loop
                        time.sleep(0.5)  # Sleep before trying again
                        continue

        except Exception as e:
            logging.error(f"Error during communication: {e}")


if __name__ == "__main__":
    start_server()
