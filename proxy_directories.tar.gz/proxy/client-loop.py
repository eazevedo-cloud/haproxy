import socket
import time

def client():
    # Create a socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Define the address and port of the server
    address = ('172.20.132.133', 5021)

    # Connect to the server
    client_socket.connect(address)

    # Get the client's IP address
    client_ip = client_socket.getsockname()[0]

    # Define the duration for sending messages (in seconds)
    duration = 15  # Replace with the desired time
    end_time = time.time() + duration

    # Initialize the counter for subsequent messages
    counter = 1

    # Send subsequent messages for the defined duration
    while time.time() < end_time:
        message = f"Hello, server! {counter:02d}"  # Format the counter with leading zeros
        client_socket.sendall(message.encode())
        
        # Receive the response from the server
        data = client_socket.recv(1024)
        print(f"Received from server: {data.decode()}")

        # Increment the counter
        counter += 1

        # Optional: Pause between messages if needed
        time.sleep(0.1)  # Send a message every 1 second

    # Close the socket
    client_socket.close()

if __name__ == "__main__":
    client()