import socket

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
    client_socket.connect(("172.20.132.134", 5021))
    message = b"Hello WebSocket via Socket!"
    print(f"Message sent: {message}")
    client_socket.sendall(message)
