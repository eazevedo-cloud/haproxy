# Proxy Protocol by HA Proxy Payload

## References

- https://discourse.haproxy.org/t/choosing-backend-based-on-tcp-payload/1600
- https://stackoverflow.com/questions/30304124/unexpected-haproxy-acl-behaviour-tcp-payload-routing