import matplotlib.pyplot as plt

# Data
technologies = ["Golang", "CSharp Core", "Java Spring Boot"]
metrics = {
    "Processing Time (ms)": [1402755, 1396543, 1641790],
    "Total Messages Processed": [1500, 1500, 1500],
    "High Priority Messages": [493, 493, 493],
    "Medium Priority Messages": [493, 493, 493],
    "Low Priority Messages": [514, 514, 514],
    "Total Matrix Operations": [245824000000, 245858004670, 245824000000],
    "Total Cryptographic Hash Operations": [33988000, 33988000, 33988000],
    "Total Dependencies Resolved": [16670, 16670, 16670],
    "Polynomial Evaluations": [762, 762, 762],
    "Average Processing Time per Message (ms)": [935, 930.44, 1094.27],
    "Fastest Processing Time (ms)": [3, 7, 3],
    "Slowest Processing Time (ms)": [6164, 6462, 7346],
}

# Loop through each metric and generate a separate bar graph
for metric, values in metrics.items():
    plt.figure(figsize=(8, 4))  # Set figure size
    plt.bar(technologies, values, color=['blue', 'green', 'orange'])  # Create bar chart
    plt.title(metric)  # Set title of the graph
    plt.ylabel("Value")  # Label y-axis
    plt.xticks(range(len(technologies)), technologies)  # Set x-axis labels
    plt.grid(axis="y", linestyle="--", alpha=0.7)  # Add gridlines to y-axis
    plt.tight_layout()  # Adjust layout to avoid overlapping
    plt.savefig(f"{metric.replace(' ', '_').replace('/', '_')}.png")  # Save graph as a PNG file
    plt.show()  # Display the graph
