### **Project Description**

This project demonstrates a Spring Boot application designed to process and analyze a collection of messages. The application simulates complex operations, including matrix multiplications, cryptographic hashing, polynomial evaluations, and dependency resolution. It provides comprehensive performance statistics, such as the average, fastest, and slowest processing times for messages.

---

### **Objective**

The objective of this project is to:

1. Benchmark CPU and memory usage during complex message processing tasks.
2. Simulate real-world workloads involving cryptographic, mathematical, and logical operations.
3. Provide detailed metrics for performance analysis.

---

### **Features**

1. **Message Processing**:

   - Processes a JSON file containing a collection of messages.
   - Simulates operations with varying complexity based on the `ComplexityFactor`.

2. **Operations**:

   - **Matrix Multiplication**: Scaled operations that stress memory and CPU.
   - **Cryptographic Hashing**: Multiple iterations of SHA256 and SHA512 hashing.
   - **Polynomial Evaluation**: Solves polynomial equations for specified values.
   - **Dependency Resolution**: Simulates graph-like traversal for dependency management.

3. **Comprehensive Metrics**:

   - Total number of messages processed.
   - Number of high, medium, and low-priority messages.
   - Total operations performed (matrix, hashing, dependency resolution).
   - Processing time metrics:
     - Total time.
     - Average processing time per message.
     - Fastest and slowest processing times.

4. **Logging**:
   - Real-time progress logs during message processing.
   - Error logs for any exceptions encountered.

---

### **Message JSON Structure**

Each message in the JSON file has the following structure:

```json
{
  "id": 35,
  "data": "HJ4TQTAICCpCSAJYp5stxB2SqRW8dJAgpA5Y0ABI7i3y9U61LfuI4",
  "priority": "High",
  "timestamp": "2024-12-02T23:40:16.077489",
  "tags": ["maintenance"],
  "metadata": {
    "source": "system1",
    "length": 53,
    "checksum": "6d75ccfefd3bb9c40242b5a75fbe1e46",
    "encryption": "RSA2048",
    "hashAlgorithm": "SHA256"
  },
  "complexityFactor": 2,
  "channel": "channel4",
  "chainId": "chain11",
  "dependencies": [5251, 7613, 8311, 3351, 9344],
  "computation": {
    "polynomial": [-9, -9, 3],
    "operation": "PolynomialEvaluation",
    "variableValue": 8
  }
}
```

#### Key Fields:

- **`id`**: Unique identifier for the message.
- **`data`**: Message content.
- **`priority`**: Processing priority (High, Medium, Low).
- **`tags`**: List of tags categorizing the message.
- **`metadata`**:
  - `source`: Origin of the message.
  - `checksum`: Integrity verification value.
  - `encryption` and `hashAlgorithm`: Information about data security.
- **`complexityFactor`**: Determines the computational load for the message.
- **`channel`** and **`chainId`**: Logical grouping for messages.
- **`dependencies`**: IDs of other messages this message depends on.
- **`computation`**:
  - `matrixA` and `matrixB`: Used in matrix multiplication.
  - `polynomial`: Coefficients for polynomial evaluation.
  - `operation`: The operation to perform (`MatrixMultiplication`, `PolynomialEvaluation`).
  - `variableValue`: Value for solving the polynomial.

---

### **How It Works**

1. **Input**:

   - The program reads a JSON file (`messages.json`) containing a list of messages.

2. **Processing**:

   - Each message undergoes processing based on its `computation` and `complexityFactor`.
   - Operations include:
     - Matrix multiplication (memory-intensive).
     - Cryptographic hashing (CPU-intensive).
     - Polynomial evaluation (mathematical operation).
     - Dependency resolution (logical operation).

3. **Metrics Collection**:

   - Logs processing time for each message.
   - Calculates total operations performed.
   - Generates detailed time statistics.

4. **Output**:
   - Summary statistics displayed in the console after processing.

---

### **Performance Metrics**

The program provides the following metrics:

- **Processing Time**:
  - Average time per message.
  - Fastest and slowest message processing times.
- **Operation Counts**:
  - Matrix operations performed.
  - Cryptographic hashing operations.
  - Dependencies resolved.
- **Priority Breakdown**:
  - Count of High, Medium, and Low-priority messages.

Example Output:

```
Processing Summary:
--------------------
Total Messages Processed: 10000
High Priority Messages: 3327
Medium Priority Messages: 3281
Low Priority Messages: 3392
Total Matrix Operations: 1658242242
Total Cryptographic Hash Operations: 56047000
Total Dependencies Resolved: 30242
Time Taken: 60221ms

Processing Time Statistics:
---------------------------
Average Processing Time per Message: 6.02ms
Fastest Processing Time: 4ms
Slowest Processing Time: 12ms
```

---

### **How to Run**

1. Ensure **Java 17** (or later) is installed on your system.
2. Ensure **Maven** or **Gradle** is installed and available in your `PATH`.
3. Clone the repository:
   ```bash
   git clone <repository-url>
   cd <project-directory>
   ```
4. Build the project using Gradle:
   ```bash
   ./gradlew build
   ```
5. Run the application:
   ```bash
   java -jar build/libs/message-processor-0.0.1-SNAPSHOT.jar
   ```

---

### **Building and Running with Docker**

To run this application within a Docker container, ensure you have Docker installed on your system and follow these steps:

1. **Build the Docker Image**:  
   In the directory containing the `Dockerfile` and `messagesSmall.json`, run:

   ```bash
   docker build -t messageprocessor:latest .
   ```

   This will create an image called `messageprocessor` with the `latest` tag.

2. **Run the Docker Container**:  
   Once the image is built, start the container:

   ```bash
   docker run --rm -it messageprocessor:latest
   ```

   - `--rm` ensures the container is removed after it stops.
   - `-it` allows you to see the console output interactively.

   The application will run inside the container and display the logs and performance metrics in your terminal.

**Note**: The `messagesSmall.json` file must be present in the same directory as the `Dockerfile` so that it's copied into the container image. If it's not included in the image, the application will not find it when running inside the container.

---

### **Files**

- **`MessageProcessorApplication.java`**: Main application file containing the processing logic.
- **`messages.json`**: Input file containing the list of messages.

---

### **Technologies Used**

- **Programming Language**: Java
- **Framework**: Spring Boot
- **Cryptographic Algorithms**: SHA256, SHA512
- **JSON Serialization**: Jackson
- **Build Tools**: Gradle

---
