package aero.sita.mercurypoc.messageprocessor;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

@SpringBootApplication
public class MessageProcessorApplication implements CommandLineRunner {

    // Static lists to retain large objects in memory
    private static List<int[][]> globalResults = new CopyOnWriteArrayList<>();
    private static List<byte[]> memoryHog = new CopyOnWriteArrayList<>();

    // Counters for specific operations
    private static int polynomialEvalCount = 0;

    public static void main(String[] args) {
        SpringApplication.run(MessageProcessorApplication.class, args);
    }

    @Override
    public void run(String... args) {
        System.out.println("Starting message processing...");

        long startTime = System.currentTimeMillis();
        String filePath = "resources/messages1.5k.json";
        File file = new File(filePath);

        if (!file.exists()) {
            System.out.println("File not found: " + filePath);
            return;
        }

        System.out.println(LocalDateTime.now() + ": Loading messages from the file...");

        List<Message> messages;
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        try {
            // Deserialize JSON to list of Message objects
            messages = mapper.readValue(file, new TypeReference<List<Message>>() {});
        } catch (IOException e) {
            System.out.println("Error reading the JSON file: " + e.getMessage());
            return;
        }

        if (messages == null || messages.isEmpty()) {
            System.out.println("No messages to process.");
            return;
        }

        System.out.println(LocalDateTime.now() + ": Loaded " + messages.size() + " messages.");

        // Processing statistics counters
        int highPriorityCount = 0, mediumPriorityCount = 0, lowPriorityCount = 0, processedCount = 0;
        long totalMatrixOps = 0, totalHashOps = 0, totalDependenciesResolved = 0;

        List<Long> processingTimes = new ArrayList<>();

        for (Message message : messages) {
            long messageStartTime = System.currentTimeMillis();

            try {
                System.out.println(LocalDateTime.now() + ": Processing message ID " + message.getId() + "...");
                processedCount++;

                // Perform complex operations and get operation counts
                long[] ops = performComplexOperations(message);
                totalMatrixOps += ops[0];
                totalHashOps += ops[1];
                totalDependenciesResolved += ops[2];

                // Track priority stats
                String priority = Optional.ofNullable(message.getPriority()).orElse("Low");
                switch (priority.toLowerCase()) {
                    case "high" -> highPriorityCount++;
                    case "medium" -> mediumPriorityCount++;
                    default -> lowPriorityCount++;
                }

                // Allocate ~5MB buffer per message to increase memory usage
                byte[] largeBuffer = new byte[5_000_000]; // ~5MB
                Arrays.fill(largeBuffer, (byte) 123);
                memoryHog.add(largeBuffer);

            } catch (Exception e) {
                System.out.println(LocalDateTime.now() + ": Error processing message ID " + message.getId() + ": " + e.getMessage());
            }

            long messageEndTime = System.currentTimeMillis();
            processingTimes.add(messageEndTime - messageStartTime);
        }

        long endTime = System.currentTimeMillis();
        System.out.println(LocalDateTime.now() + ": Finished processing in " + (endTime - startTime) + "ms.");

        // Calculate processing time statistics
        long totalProcessingTime = processingTimes.stream().mapToLong(Long::longValue).sum();
        double averageProcessingTime = processingTimes.stream().mapToLong(Long::longValue).average().orElse(0.0);
        long fastestProcessingTime = processingTimes.stream().mapToLong(Long::longValue).min().orElse(0L);
        long slowestProcessingTime = processingTimes.stream().mapToLong(Long::longValue).max().orElse(0L);

        // Print processing summary
        System.out.println("\nProcessing Summary:");
        System.out.println("-------------------------");
        System.out.println("Total Messages Processed: " + processedCount);
        System.out.println("High Priority Messages: " + highPriorityCount);
        System.out.println("Medium Priority Messages: " + mediumPriorityCount);
        System.out.println("Low Priority Messages: " + lowPriorityCount);
        System.out.println("Total Matrix Operations: " + totalMatrixOps);
        System.out.println("Total Cryptographic Hash Operations: " + totalHashOps);
        System.out.println("Total Dependencies Resolved: " + totalDependenciesResolved);
        System.out.println("Polynomial Evaluations: " + polynomialEvalCount);
        System.out.println("Total Time: " + (endTime - startTime) + "ms");

        System.out.println("\nProcessing Time Statistics:");
        System.out.println("---------------------------------------");
        System.out.println("Average Processing Time per Message: " + String.format("%.2f", averageProcessingTime) + "ms");
        System.out.println("Fastest Processing Time: " + fastestProcessingTime + "ms");
        System.out.println("Slowest Processing Time: " + slowestProcessingTime + "ms");

        System.out.println("\nProcessing completed successfully.");
    }

    private static long[] performComplexOperations(Message message) throws NoSuchAlgorithmException {
        long matrixOps = 0, hashOps = 0, dependenciesResolved = 0;

        Computation computation = message.getComputation();
        if (computation != null) {
            String operation = computation.getOperation();

            if ("MatrixMultiplication".equalsIgnoreCase(operation) && computation.getMatrixA() != null && computation.getMatrixB() != null) {
                // Mantemos a mesma lógica de % 3, para se alinhar ao C#
                matrixOps = multiplyLargeMatrices(computation.getMatrixA(), computation.getMatrixB(), message.getComplexityFactor());
            } else if ("PolynomialEvaluation".equalsIgnoreCase(operation) && computation.getPolynomial() != null) {
                evaluatePolynomial(computation.getPolynomial(), computation.getVariableValue());
                polynomialEvalCount++;
            }
        }

        // Ajuste para ser igual ao C#: sempre realiza SHA-256 e SHA-512, duas operações por iteração
        if (message.getComplexityFactor() > 0) {
            hashOps = performCryptographicHashing(message.getData(), message.getComplexityFactor());
        }

        if (message.getDependencies() != null && !message.getDependencies().isEmpty()) {
            dependenciesResolved = resolveDependencies(message.getDependencies());
        }

        return new long[]{matrixOps, hashOps, dependenciesResolved};
    }

    // Agora realiza a lógica de hashing igual ao C#, fazendo SHA-256 e SHA-512 a cada iteração
    private static long performCryptographicHashing(String data, int iterations) throws NoSuchAlgorithmException {
        long operationCount = 0;
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        MessageDigest sha512 = MessageDigest.getInstance("SHA-512");
        byte[] bytes = data.getBytes();

        for (int i = 0; i < iterations * 2000; i++) {
            sha256.update(bytes);
            sha256.digest();
            sha512.update(bytes);
            sha512.digest();
            operationCount += 2; // duas operações de hash por iteração, como no C#
        }
        return operationCount;
    }

    private static long resolveDependencies(List<Integer> dependencies) {
        Collections.sort(dependencies);
        return (long) dependencies.size() * dependencies.size(); // Simulate graph traversal complexity
    }

    private static long multiplyLargeMatrices(List<List<Integer>> matrixA, List<List<Integer>> matrixB, int scaleFactor) {
        int size = 100 * scaleFactor;
        int[][] result = new int[size][size];
        long operations = 0;

        // Mesma lógica do C#: usando i%3, k%3 e j%3
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                result[i][j] = 0;
                for (int k = 0; k < size; k++) {
                    result[i][j] += matrixA.get(i % 3).get(k % 3) * matrixB.get(k % 3).get(j % 3);
                    operations++;
                }
            }
        }

        globalResults.add(result);
        return operations;
    }

    private static double evaluatePolynomial(List<Integer> coefficients, int variableValue) {
        double result = 0.0;
        for (int i = 0; i < coefficients.size(); i++) {
            result += coefficients.get(i) * Math.pow(variableValue, i);
        }
        return result;
    }

    // Inner classes to represent Message, Metadata, and Computation
    static class Message {
        @JsonProperty("Id")
        private int Id;
        @JsonProperty("Data")
        private String Data;
        @JsonProperty("Priority")
        private String Priority;
        @JsonProperty("Timestamp")
        private LocalDateTime Timestamp;
        @JsonProperty("Tags")
        private List<String> Tags;
        @JsonProperty("Metadata")
        private Metadata Metadata;
        @JsonProperty("ComplexityFactor")
        private int ComplexityFactor;
        @JsonProperty("Channel")
        private String Channel;
        @JsonProperty("ChainId")
        private String ChainId;
        @JsonProperty("Dependencies")
        private List<Integer> Dependencies;
        @JsonProperty("Computation")
        private Computation Computation;

        // Getters and Setters
        public int getId() { return Id; }
        public void setId(int id) { Id = id; }
        public String getData() { return Data; }
        public void setData(String data) { Data = data; }
        public String getPriority() { return Priority; }
        public void setPriority(String priority) { Priority = priority; }
        public LocalDateTime getTimestamp() { return Timestamp; }
        public void setTimestamp(LocalDateTime timestamp) { Timestamp = timestamp; }
        public List<String> getTags() { return Tags; }
        public void setTags(List<String> tags) { Tags = tags; }
        public Metadata getMetadata() { return Metadata; }
        public void setMetadata(Metadata metadata) { Metadata = metadata; }
        public int getComplexityFactor() { return ComplexityFactor; }
        public void setComplexityFactor(int complexityFactor) { ComplexityFactor = complexityFactor; }
        public String getChannel() { return Channel; }
        public void setChannel(String channel) { Channel = channel; }
        public String getChainId() { return ChainId; }
        public void setChainId(String chainId) { ChainId = chainId; }
        public List<Integer> getDependencies() { return Dependencies; }
        public void setDependencies(List<Integer> dependencies) { Dependencies = dependencies; }
        public Computation getComputation() { return Computation; }
        public void setComputation(Computation computation) { Computation = computation; }
    }

    static class Metadata {
        @JsonProperty("Source")
        private String Source;
        @JsonProperty("Length")
        private int Length;
        @JsonProperty("Checksum")
        private String Checksum;
        @JsonProperty("Encryption")
        private String Encryption;
        @JsonProperty("HashAlgorithm")
        private String HashAlgorithm;

        // Getters and Setters
        public String getSource() { return Source; }
        public void setSource(String source) { Source = source; }
        public int getLength() { return Length; }
        public void setLength(int length) { Length = length; }
        public String getChecksum() { return Checksum; }
        public void setChecksum(String checksum) { Checksum = checksum; }
        public String getEncryption() { return Encryption; }
        public void setEncryption(String encryption) { Encryption = encryption; }
        public String getHashAlgorithm() { return HashAlgorithm; }
        public void setHashAlgorithm(String hashAlgorithm) { HashAlgorithm = hashAlgorithm; }
    }


    static class Computation {
        @JsonProperty("MatrixA")
        private List<List<Integer>> MatrixA;
        @JsonProperty("MatrixB")
        private List<List<Integer>> MatrixB;
        @JsonProperty("Operation")
        private String Operation;
        @JsonProperty("Polynomial")
        private List<Integer> Polynomial;
        @JsonProperty("VariableValue")
        private int VariableValue;

        // Getters and Setters
        public List<List<Integer>> getMatrixA() { return MatrixA; }
        public void setMatrixA(List<List<Integer>> matrixA) { MatrixA = matrixA; }
        public List<List<Integer>> getMatrixB() { return MatrixB; }
        public void setMatrixB(List<List<Integer>> matrixB) { MatrixB = matrixB; }
        public String getOperation() { return Operation; }
        public void setOperation(String operation) { Operation = operation; }
        public List<Integer> getPolynomial() { return Polynomial; }
        public void setPolynomial(List<Integer> polynomial) { Polynomial = polynomial; }
        public int getVariableValue() { return VariableValue; }
        public void setVariableValue(int variableValue) { VariableValue = variableValue; }
    }
}
