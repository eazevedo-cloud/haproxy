#!/bin/sh
docker build -f Dockerfile -t java-spring-boot:1.0.5 .
#docker tag 50e76dd58e87 pocmercury.azurecr.io/language-selection/java-spring-boot:1.0.5
#docker push pocmercury.azurecr.io/language-selection/java-spring-boot:1.0.5