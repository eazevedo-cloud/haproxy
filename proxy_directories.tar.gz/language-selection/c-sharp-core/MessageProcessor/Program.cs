﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;

namespace MessageProcessor
{
    public class Message
    {
        public int Id { get; set; }
        public string Data { get; set; }
        public string Priority { get; set; }
        public DateTime Timestamp { get; set; }
        public List<string> Tags { get; set; }
        public Metadata Metadata { get; set; }
        public int ComplexityFactor { get; set; }
        public string Channel { get; set; }
        public string ChainId { get; set; }
        public List<int> Dependencies { get; set; }
        public Computation Computation { get; set; }
    }

    public class Metadata
    {
        public string Source { get; set; }
        public int Length { get; set; }
        public string Checksum { get; set; }
        public string Encryption { get; set; }
        public string HashAlgorithm { get; set; }
    }

    public class Computation
    {
        public List<List<int>> MatrixA { get; set; }
        public List<List<int>> MatrixB { get; set; }
        public string Operation { get; set; }
        public List<int> Polynomial { get; set; }
        public int VariableValue { get; set; }
    }

    class Program
    {
        // Static lists to retain large objects in memory, increasing memory usage over time.
        static List<int[,]> GlobalResults = new List<int[,]>();
        static List<byte[]> MemoryHog = new List<byte[]>();

        // Counters to track how many polynomial computations were performed
        static int polynomialEvalCount = 0;

        static void Main(string[] args)
        {
            Console.WriteLine("Starting message processing...");

            var stopwatch = Stopwatch.StartNew();

            string filePath = "messages1.5k.json";
            if (!File.Exists(filePath))
            {
                Console.WriteLine($"File not found: {filePath}");
                return;
            }

            Console.WriteLine($"{DateTime.Now}: Loading messages from file...");
            var jsonData = File.ReadAllText(filePath);
            
            // Deserialize the JSON file into a list of Message objects.
            var messages = JsonSerializer.Deserialize<List<Message>>(jsonData, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });

            if (messages == null || !messages.Any())
            {
                Console.WriteLine("No messages to process.");
                return;
            }

            Console.WriteLine($"{DateTime.Now}: Loaded {messages.Count} messages.");

            int highPriorityCount = 0, lowPriorityCount = 0, mediumPriorityCount = 0, processedCount = 0;
            long totalMatrixOps = 0, totalHashOps = 0, totalDependenciesResolved = 0;
            
            var priorityStats = new Dictionary<string, int>();
            var processingTimes = new List<long>();

            foreach (var message in messages)
            {
                var messageStopwatch = Stopwatch.StartNew(); // Track the time for each message

                try
                {
                    Console.WriteLine($"{DateTime.Now}: Processing message ID {message.Id}...");
                    processedCount++;

                    // Perform all complex operations and retrieve operation counts
                    long matrixOps = PerformComplexOperations(message, out long hashOps, out long dependenciesResolved);
                    totalMatrixOps += matrixOps;
                    totalHashOps += hashOps;
                    totalDependenciesResolved += dependenciesResolved;

                    // Count messages by priority
                    if (message.Priority.Equals("High", StringComparison.OrdinalIgnoreCase)) highPriorityCount++;
                    else if (message.Priority.Equals("Medium", StringComparison.OrdinalIgnoreCase)) mediumPriorityCount++;
                    else lowPriorityCount++;

                    if (!priorityStats.ContainsKey(message.Priority))
                        priorityStats[message.Priority] = 0;
                    priorityStats[message.Priority]++;

                    // Allocate a 5MB buffer per message to increase memory usage,
                    // but less aggressively than previous attempts.
                    byte[] largeBuffer = new byte[5_000_000]; // ~5MB
                    // Write every 200th byte to avoid too much CPU overhead
                    for (int i = 0; i < largeBuffer.Length; i += 200)
                    {
                        largeBuffer[i] = 123;
                    }
                    MemoryHog.Add(largeBuffer);

                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{DateTime.Now}: Error processing message ID {message.Id}: {ex.Message}");
                }

                messageStopwatch.Stop();
                processingTimes.Add(messageStopwatch.ElapsedMilliseconds); // Log processing time for this message
            }

            stopwatch.Stop();
            Console.WriteLine($"{DateTime.Now}: Finished processing in {stopwatch.ElapsedMilliseconds}ms.");

            // Calculate timing statistics
            long totalProcessingTime = processingTimes.Sum();
            double averageProcessingTime = processingTimes.Any() ? processingTimes.Average() : 0;
            long fastestProcessingTime = processingTimes.Any() ? processingTimes.Min() : 0;
            long slowestProcessingTime = processingTimes.Any() ? processingTimes.Max() : 0;

            // Print a summary of all processing statistics
            Console.WriteLine("\nProcessing Summary:");
            Console.WriteLine("--------------------");
            Console.WriteLine($"Total Messages Processed: {processedCount}");
            Console.WriteLine($"High Priority Messages: {highPriorityCount}");
            Console.WriteLine($"Medium Priority Messages: {mediumPriorityCount}");
            Console.WriteLine($"Low Priority Messages: {lowPriorityCount}");
            Console.WriteLine($"Total Matrix Operations: {totalMatrixOps}");
            Console.WriteLine($"Total Cryptographic Hash Operations: {totalHashOps}");
            Console.WriteLine($"Total Dependencies Resolved: {totalDependenciesResolved}");
            Console.WriteLine($"Polynomial Evaluations: {polynomialEvalCount}"); // New statistic for polynomial evaluation count
            Console.WriteLine($"Time Taken: {stopwatch.ElapsedMilliseconds}ms");

            Console.WriteLine("\nProcessing Time Statistics:");
            Console.WriteLine("---------------------------");
            Console.WriteLine($"Average Processing Time per Message: {averageProcessingTime:F2}ms");
            Console.WriteLine($"Fastest Processing Time: {fastestProcessingTime}ms");
            Console.WriteLine($"Slowest Processing Time: {slowestProcessingTime}ms");

            Console.WriteLine("\nProcessing completed successfully.");
        }

        /// <summary>
        /// Performs the complex operations defined by the message: matrix multiplication,
        /// polynomial evaluation, hashing, and dependency resolution.
        /// </summary>
        static long PerformComplexOperations(Message message, out long hashOps, out long dependenciesResolved)
        {
            long operations = 0;
            hashOps = 0;
            dependenciesResolved = 0;

            // If operation is MatrixMultiplication, multiply large matrices to stress CPU and memory
            if (message.Computation.Operation == "MatrixMultiplication" &&
                message.Computation.MatrixA != null &&
                message.Computation.MatrixB != null)
            {
                operations += MultiplyLargeMatrices(message.Computation.MatrixA, message.Computation.MatrixB, message.ComplexityFactor);
            }
            // If operation is PolynomialEvaluation, evaluate the polynomial for the given variableValue
            else if (message.Computation.Operation == "PolynomialEvaluation" &&
                     message.Computation.Polynomial != null)
            {
                double polynomialValue = EvaluatePolynomial(message.Computation.Polynomial, message.Computation.VariableValue);
                polynomialEvalCount++; // Increment polynomial evaluation count
            }

            // Perform cryptographic hashing multiple times depending on ComplexityFactor
            if (message.ComplexityFactor > 0)
            {
                hashOps = PerformCryptographicHashing(message.Data, message.ComplexityFactor);
                operations += hashOps;
            }

            // Resolve dependencies (simulated by sorting and doing a simple computation)
            if (message.Dependencies != null && message.Dependencies.Any())
            {
                dependenciesResolved = ResolveDependencies(message.Dependencies);
                operations += dependenciesResolved;
            }

            return operations;
        }

        /// <summary>
        /// Perform SHA256 and SHA512 hashing multiple times to stress CPU.
        /// The number of iterations depends on ComplexityFactor.
        /// </summary>
        static long PerformCryptographicHashing(string data, int iterations)
        {
            long operationCount = 0;
            using var sha256 = SHA256.Create();
            using var sha512 = SHA512.Create();

            // For each iteration, we do a number of hash computations to stress the CPU
            for (int i = 0; i < iterations * 2000; i++)
            {
                sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(data));
                sha512.ComputeHash(System.Text.Encoding.UTF8.GetBytes(data));
                operationCount += 2;
            }

            return operationCount;
        }

        /// <summary>
        /// Simulate dependency resolution by sorting and doing a simple operation
        /// proportional to the number of dependencies.
        /// </summary>
        static long ResolveDependencies(List<int> dependencies)
        {
            dependencies.Sort();
            return dependencies.Count * dependencies.Count; // Simulate a graph traversal complexity
        }

        /// <summary>
        /// Multiply large matrices, scaling up their size based on the ComplexityFactor.
        /// Storing the result in a global list to ensure memory is retained.
        /// </summary>
        static long MultiplyLargeMatrices(List<List<int>> matrixA, List<List<int>> matrixB, int scaleFactor)
        {
            // Size is larger than the original version (50), but smaller than the extreme attempts.
            // This will increase memory usage, but not as drastically.
            int size = 100 * scaleFactor;
            var result = new int[size, size];
            long operations = 0;

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    result[i, j] = 0;
                    for (int k = 0; k < size; k++)
                    {
                        // We reuse the small 3x3 matrices as a pattern
                        result[i, j] += matrixA[i % 3][k % 3] * matrixB[k % 3][j % 3];
                        operations++;
                    }
                }
            }

            // Keep the result globally so it's not GC'ed, increasing memory usage.
            GlobalResults.Add(result);

            return operations;
        }

        /// <summary>
        /// Evaluate a polynomial of the form:
        /// sum(coefficients[i] * variableValue^i) for i in [0, coefficients.Count)
        /// </summary>
        static double EvaluatePolynomial(List<int> coefficients, int variableValue)
        {
            double result = 0;
            for (int i = 0; i < coefficients.Count; i++)
            {
                result += coefficients[i] * Math.Pow(variableValue, i);
            }
            return result;
        }
    }
}
