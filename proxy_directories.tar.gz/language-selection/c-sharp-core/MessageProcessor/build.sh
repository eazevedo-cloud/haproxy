#!/bin/sh
docker build -f Dockerfile -t c-sharp-core:1.0.2 .
#docker tag 2407a2283848 pocmercury.azurecr.io/language-selection/c-sharp-core:1.0.2
#docker push pocmercury.azurecr.io/language-selection/c-sharp-core:1.0.2
