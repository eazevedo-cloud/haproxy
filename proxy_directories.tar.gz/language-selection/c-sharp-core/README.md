### **Project Description**

This project demonstrates a high-performance benchmark application designed to process and analyze a collection of messages. The application simulates complex operations such as matrix multiplications, cryptographic hashing, dependency resolution, and polynomial evaluations. It provides comprehensive performance statistics, including average, fastest, and slowest processing times for messages.

---

### **Objective**

The objective of this project is to:

1. Benchmark CPU and memory usage during complex message processing tasks.
2. Simulate real-world workloads involving cryptographic, mathematical, and logical operations.
3. Provide detailed metrics for performance analysis.

---

### **Features**

1. **Message Processing**:

   - Processes a JSON file containing a collection of messages.
   - Simulates operations with varying complexity based on `ComplexityFactor`.

2. **Operations**:

   - **Matrix Multiplication**: Scaled operations to stress memory and CPU.
   - **Cryptographic Hashing**: Multiple iterations of SHA256 and SHA512 hashing.
   - **Polynomial Evaluation**: Solves polynomial equations for specified values.
   - **Dependency Resolution**: Simulates graph-like traversal for dependency management.

3. **Comprehensive Metrics**:

   - Total number of messages processed.
   - Number of high, medium, and low-priority messages.
   - Total operations performed (matrix, hashing, dependency resolution).
   - Processing time metrics:
     - Total time.
     - Average processing time per message.
     - Fastest and slowest processing times.

4. **Logging**:
   - Real-time progress logs during message processing.
   - Error logs for any exceptions encountered.

---

### **Message JSON Structure**

Each message in the JSON file has the following structure:

```json
{
  "Id": 35,
  "Data": "HJ4TQTAICCpCSAJYp5stxB2SqRW8dJAgpA5Y0ABI7i3y9U61LfuI4",
  "Priority": "High",
  "Timestamp": "2024-12-02T23:40:16.077489",
  "Tags": ["maintenance"],
  "Metadata": {
    "Source": "system1",
    "Length": 53,
    "Checksum": "6d75ccfefd3bb9c40242b5a75fbe1e46",
    "Encryption": "RSA2048",
    "HashAlgorithm": "SHA256"
  },
  "ComplexityFactor": 2,
  "Channel": "channel4",
  "ChainId": "chain11",
  "Dependencies": [5251, 7613, 8311, 3351, 9344],
  "Computation": {
    "Polynomial": [-9, -9, 3],
    "Operation": "PolynomialEvaluation",
    "VariableValue": 8
  }
}
```

#### Key Fields:

- **`Id`**: Unique identifier for the message.
- **`Data`**: Message content.
- **`Priority`**: Processing priority (High, Medium, Low).
- **`Tags`**: List of tags categorizing the message.
- **`Metadata`**:
  - `Source`: Origin of the message.
  - `Checksum`: Integrity verification value.
  - `Encryption` and `HashAlgorithm`: Information about data security.
- **`ComplexityFactor`**: Determines the computational load for the message.
- **`Channel`** and **`ChainId`**: Logical grouping for messages.
- **`Dependencies`**: IDs of other messages this message depends on.
- **`Computation`**:
  - `MatrixA` and `MatrixB`: Used in matrix multiplication.
  - `Polynomial`: Coefficients for polynomial evaluation.
  - `Operation`: The operation to perform (`MatrixMultiplication`, `PolynomialEvaluation`).
  - `VariableValue`: Value for solving the polynomial.

---

### **How It Works**

1. **Input**:

   - The program reads a JSON file (`messages.json`) containing a list of messages.

2. **Processing**:

   - Each message undergoes processing based on its `Computation` and `ComplexityFactor`.
   - Operations include:
     - Matrix multiplication (memory-intensive).
     - Cryptographic hashing (CPU-intensive).
     - Polynomial evaluation (mathematical operation).
     - Dependency resolution (logical operation).

3. **Metrics Collection**:

   - Logs processing time for each message.
   - Calculates total operations performed.
   - Generates detailed time statistics.

4. **Output**:
   - Summary statistics displayed in the console after processing.

---

### **Performance Metrics**

The program provides the following metrics:

- **Processing Time**:
  - Average time per message.
  - Fastest and slowest message processing times.
- **Operation Counts**:
  - Matrix operations performed.
  - Cryptographic hashing operations.
  - Dependencies resolved.
- **Priority Breakdown**:
  - Count of High, Medium, and Low-priority messages.

Example Output:

```
Processing Summary:
--------------------
Total Messages Processed: 10000
High Priority Messages: 3327
Medium Priority Messages: 3281
Low Priority Messages: 3392
Total Matrix Operations: 1658242242
Total Cryptographic Hash Operations: 56047000
Total Dependencies Resolved: 30242
Time Taken: 60221ms

Processing Time Statistics:
---------------------------
Average Processing Time per Message: 6.02ms
Fastest Processing Time: 4ms
Slowest Processing Time: 12ms
```

---

### **How to Run**

1. Ensure .NET Core SDK is installed.
2. Place the `messages.json` file in the project directory.
3. Compile the program:
   ```bash
   dotnet build
   ```
4. Run the program:
   ```bash
   dotnet run
   ```

---

### **Building and Running with Docker**

To run this application within a Docker container, ensure you have Docker installed on your system and follow these steps:

1. **Build the Docker Image**:  
   In the directory containing the `Dockerfile` and `messagesSmall.json`, run:

   ```bash
   docker build -t messageprocessor:latest .
   ```

   This will create an image called `messageprocessor` with the `latest` tag.

2. **Run the Docker Container**:  
   Once the image is built, start the container:

   ```bash
   docker run --rm -it messageprocessor:latest
   ```

   - `--rm` ensures the container is removed after it stops.
   - `-it` allows you to see the console output interactively.

   The application will run inside the container and display the logs and performance metrics in your terminal.

**Note**: The `messagesSmall.json` file must be present in the same directory as the `Dockerfile` so that it's copied into the container image. If it's not included in the image, the application will not find it when running inside the container.

---

### **Files**

- **`Program.cs`**: Main program file containing the processing logic.
- **`messages.json`**: Input file containing the list of messages.

---

### **Technologies Used**

- **Programming Language**: C#
- **Framework**: .NET Core
- **Cryptographic Algorithms**: SHA256, SHA512
- **JSON Serialization**: `System.Text.Json`

---
