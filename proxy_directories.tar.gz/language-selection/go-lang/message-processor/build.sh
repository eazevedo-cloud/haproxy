#!/bin/sh
docker build -f Dockerfile -t go-lang:1.0.2 .
#docker tag a21b02d33a98 pocmercury.azurecr.io/language-selection/go-lang:1.0.2
#docker push pocmercury.azurecr.io/language-selection/go-lang:1.0.2