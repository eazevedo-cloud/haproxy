package main

import (
	"crypto/sha256"
	"crypto/sha512"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"math"
	"sort"
	"time"
)

// Message represents the structure of a single message to be processed.
type Message struct {
	Id               int         `json:"Id"`
	Data             string      `json:"Data"`
	Priority         string      `json:"Priority"`
	Timestamp        string      `json:"Timestamp"`
	Tags             []string    `json:"Tags"`
	Metadata         Metadata    `json:"Metadata"`
	ComplexityFactor int         `json:"ComplexityFactor"`
	Channel          string      `json:"Channel"`
	ChainId          string      `json:"ChainId"`
	Dependencies     []int       `json:"Dependencies"`
	Computation      Computation `json:"Computation"`
}

// Metadata represents additional information about a message.
type Metadata struct {
	Source        string `json:"Source"`
	Length        int    `json:"Length"`
	Checksum      string `json:"Checksum"`
	Encryption    string `json:"Encryption"`
	HashAlgorithm string `json:"HashAlgorithm"`
}

// Computation represents the computational tasks associated with a message.
type Computation struct {
	MatrixA       [][]int `json:"MatrixA"`
	MatrixB       [][]int `json:"MatrixB"`
	Operation     string  `json:"Operation"`
	Polynomial    []int   `json:"Polynomial"`
	VariableValue int     `json:"VariableValue"`
}

var (
	// globalResults stores the results of matrix operations to prevent garbage collection and simulate memory usage.
	globalResults = [][]int{}
	// memoryHog stores large byte arrays to artificially increase memory usage.
	memoryHog = [][]byte{}
	// polynomialEvalCount tracks the number of polynomial evaluations performed.
	polynomialEvalCount int
)

func main() {
	fmt.Println("Starting message processing...")
	start := time.Now()

	filePath := "messages1.5k.json"
	// Read the JSON file containing the messages.
	data, err := ioutil.ReadFile(filePath)
	if err != nil {
		fmt.Printf("File not found: %s\n", filePath)
		return
	}

	var messages []Message
	// Parse the JSON data into a slice of Message structs.
	err = json.Unmarshal(data, &messages)
	if err != nil {
		fmt.Printf("Error parsing JSON: %s\n", err)
		return
	}

	if len(messages) == 0 {
		fmt.Println("No messages to process.")
		return
	}

	fmt.Printf("%s: Loaded %d messages.\n", time.Now().Format(time.RFC3339), len(messages))

	highPriorityCount := 0
	mediumPriorityCount := 0
	lowPriorityCount := 0
	totalMatrixOps := 0
	totalHashOps := 0
	totalDependenciesResolved := 0
	processingTimes := []time.Duration{}

	// Process each message and track statistics.
	for _, message := range messages {
		messageStart := time.Now()

		fmt.Printf("%s: Processing message ID %d...\n", time.Now().Format(time.RFC3339), message.Id)

		matrixOps, hashOps, dependenciesResolved := performComplexOperations(message)
		totalMatrixOps += matrixOps
		totalHashOps += hashOps
		totalDependenciesResolved += dependenciesResolved

		switch message.Priority {
		case "High":
			highPriorityCount++
		case "Medium":
			mediumPriorityCount++
		default:
			lowPriorityCount++
		}

		// Allocate a large buffer to simulate increased memory usage.
		largeBuffer := make([]byte, 5_000_000)
		for i := 0; i < len(largeBuffer); i += 200 {
			largeBuffer[i] = 123
		}
		memoryHog = append(memoryHog, largeBuffer)

		processingTimes = append(processingTimes, time.Since(messageStart))
	}

	totalTime := time.Since(start)
	fmt.Printf("%s: Finished processing in %dms.\n", time.Now().Format(time.RFC3339), totalTime.Milliseconds())

	// Calculate average, fastest, and slowest processing times.
	averageProcessingTime := totalTime.Milliseconds() / int64(len(messages))
	fastestProcessingTime := processingTimes[0]
	slowestProcessingTime := processingTimes[0]
	for _, t := range processingTimes {
		if t < fastestProcessingTime {
			fastestProcessingTime = t
		}
		if t > slowestProcessingTime {
			slowestProcessingTime = t
		}
	}

	// Print summary of processing statistics.
	fmt.Println("\nProcessing Summary:")
	fmt.Println("-------------------------")
	fmt.Printf("Total Messages Processed: %d\n", len(messages))
	fmt.Printf("High Priority Messages: %d\n", highPriorityCount)
	fmt.Printf("Medium Priority Messages: %d\n", mediumPriorityCount)
	fmt.Printf("Low Priority Messages: %d\n", lowPriorityCount)
	fmt.Printf("Total Matrix Operations: %d\n", totalMatrixOps)
	fmt.Printf("Total Cryptographic Hash Operations: %d\n", totalHashOps)
	fmt.Printf("Total Dependencies Resolved: %d\n", totalDependenciesResolved)
	fmt.Printf("Polynomial Evaluations: %d\n", polynomialEvalCount)

	fmt.Println("\nProcessing Time Statistics:")
	fmt.Println("---------------------------------------")
	fmt.Printf("Average Processing Time per Message: %dms\n", averageProcessingTime)
	fmt.Printf("Fastest Processing Time: %dms\n", fastestProcessingTime.Milliseconds())
	fmt.Printf("Slowest Processing Time: %dms\n", slowestProcessingTime.Milliseconds())

	fmt.Println("\nProcessing completed successfully.")
}

// performComplexOperations processes a single message and returns counts of various operations.
func performComplexOperations(message Message) (int, int, int) {
	matrixOps := 0
	hashOps := performCryptographicHashing(message.Data, message.ComplexityFactor)
	dependenciesResolved := resolveDependencies(message.Dependencies)

	if message.Computation.Operation == "MatrixMultiplication" {
		matrixOps = multiplyMatrices(message.Computation.MatrixA, message.Computation.MatrixB, message.ComplexityFactor)
	} else if message.Computation.Operation == "PolynomialEvaluation" {
		evaluatePolynomial(message.Computation.Polynomial, message.Computation.VariableValue)
		polynomialEvalCount++
	}

	return matrixOps, hashOps, dependenciesResolved
}

// performCryptographicHashing performs SHA-256 and SHA-512 hashing multiple times to stress the CPU.
func performCryptographicHashing(data string, iterations int) int {
	hashOps := 0
	for i := 0; i < iterations*2000; i++ {
		hash := sha256.Sum256([]byte(data))
		hash512 := sha512.Sum512(hash[:])
		hashOps += 2
		_ = hash512 // Discard result to simulate computation.
	}
	return hashOps
}

// resolveDependencies simulates dependency resolution by sorting and performing a quadratic operation.
func resolveDependencies(dependencies []int) int {
	sort.Ints(dependencies)
	return len(dependencies) * len(dependencies)
}

// multiplyMatrices multiplies two matrices and scales the size based on the complexity factor.
func multiplyMatrices(matrixA, matrixB [][]int, scaleFactor int) int {
	size := 100 * scaleFactor
	result := make([][]int, size)
	for i := range result {
		result[i] = make([]int, size)
	}

	opCount := 0
	for i := 0; i < size; i++ {
		for j := 0; j < size; j++ {
			for k := 0; k < size; k++ {
				result[i][j] += matrixA[i%3][k%3] * matrixB[k%3][j%3]
				opCount++
			}
		}
	}
	globalResults = append(globalResults, result...)
	return opCount
}

// evaluatePolynomial evaluates a polynomial for a given variable using the provided coefficients.
func evaluatePolynomial(coefficients []int, variable int) float64 {
	result := 0.0
	for i, coef := range coefficients {
		result += float64(coef) * math.Pow(float64(variable), float64(i))
	}
	return result
}
