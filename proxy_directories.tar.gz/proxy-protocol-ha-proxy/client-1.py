import socket


def client():
    # Create a socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Define the address and port of the server
    address = ("172.20.132.134", 5021)

    # Connect to the server
    client_socket.connect(address)

    # Prepare the Proxy Protocol header
    proxy_protocol_header = "PROXY TCP4 192.168.0.1 10.37.0.4 12345 5021\r\n"

    # Send the Proxy Protocol header
    client_socket.sendall(proxy_protocol_header.encode())

    # Send a message
    message = "Hello, this is the proxy protocol test from vm machine!"
    client_socket.sendall(message.encode())

    # Receive the response from the server
    data = client_socket.recv(1024)
    print(f"Received from server: {data.decode()}")

    # Close the socket
    client_socket.close()


if __name__ == "__main__":
    client()
